﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace targhe
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //char[] lettere = new char['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
            char[] lettere = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".ToCharArray();
            char[] targa = new char[7];
            int totale = 0;
            int lettera;
            int esponente = 0;
            bool trovato = false;
            Console.WriteLine("Inseire la targa nel formato LLLLNNN");
            Console.WriteLine("inserire la targa carattere per carattere");
        for (int i = 0; i < targa.Length; i++)
            {
                targa[i] = Convert.ToChar(Console.ReadLine().ToUpper());
            }
            for (int i = 0; i <= 4; i++)
            {
                for (int j = 0; j < 26 && trovato == true; j++)
                {
                    if (targa[i] == lettere[j])
                    {
                        trovato = true;
                        lettera = j;
                        totale = totale + j * (26 ^ i) * 10 ^ 3;
                    }
                }
               
    
            trovato = false;
            }
            for (int i = 4; i < 7; i++)
            {
                esponente++;
                totale = totale + targa[i] * 10 ^ esponente;
    
             }
            Console.WriteLine(totale);
            Console.ReadLine();

        }
    }
}
